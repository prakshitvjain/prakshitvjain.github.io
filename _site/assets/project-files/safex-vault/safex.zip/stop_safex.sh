#!/bin/bash
sudo systemctl stop httpd
sudo systemctl stop mariadb
echo "Successfully Executed";
